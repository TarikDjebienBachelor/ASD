README : 

// Auteur : Djebien Tarik
// Date   : Mars 2010
// Objet  : ASD - Alignement de deux mots

Ci-Joint le TP numero 3

Arborescence de l'archive Tarik_Djebien.tar.gz :
    |
    |_____README.txt
    |
    |_____tp3.pdf
    |
    |_____Tp3/
           |
           |
           |__Exo2/ Alignement_de_deux_mots.pas

Pour les commentaires :

tarik.djebien@etudiant.univ-lille1.fr

Cordialement.
